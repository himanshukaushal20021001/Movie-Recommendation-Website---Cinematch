import logo from "../assets/logo.png";
const Header = () => {
  return (
    <div>
      <img src={logo} alt="logo" className="absolute z-10 w-48 " />
    </div>
  );
};

export default Header;
