export const api_options = {
  method: "GET",
  headers: {
    accept: "application/json",
    Authorization:
      "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI2MTFkZDcyMDE0ZmQxMjlhNjFhMjUxOWUwMGZjMjQ5NyIsInN1YiI6IjY2NTNhNDVmMzYyMWEzMGNiYTBjODIxYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.54m0DO_PGjaUnfB4AIIagwfm4OeXQgo-aLqrptZY9uc",
  },
};
export const img_url = "https://image.tmdb.org/t/p/w780/";
export const img_urlb = "https://image.tmdb.org/t/p/w1280/";
export const img_logo = "https://image.tmdb.org/t/p/original/";
export const img_pp = "https://image.tmdb.org/t/p/w500";
export const img_img = "https://image.tmdb.org/t/p/w500";
export const vid_url = "https://www.youtube.com/watch?v=";
